# Lab 2: Writing and the org brain

[Participant Hub](https://wf-ai-labs.rw.institute/participant#lab-2) · Today’s win worksheet

Make Claude sound like your organization. Leave with saved voice notes and, if time permits, one real draft.

Claude handles the files. You choose what sounds like you and check the facts.

## Before you come

Use the current Lab Guide in Claude desktop or your browser. Reuse work already available in your session.
Cowork: choose the existing AI-Labs folder for local file editing. Browser: use your Project or the current chat.
No repeat downloads or file moving. Claude uses the files it can actually access.

### Desktop installation: three clicks

1. Customize → Plugins → Add marketplace → Add from a repository.
2. Enter `chrisjarviscan/wf-lab-guide`. Install **wf-lab-guide**.
3. Select **lab-guide** from `/` in your Cowork session.

### Two short checks

```prompt
Is the guide working?
```

Pass: current version, Lab 2 and today's time. Monday, October 5: 1:00–2:30 PM Eastern (noon–1:30 Central).

```prompt
Check and fix setup.
```

Claude checks the connected folder, adds missing lab files and reports unfinished instructions.
Cowork access: select your existing AI-Labs folder when requested. Browser chats do not need that connection to begin.
Claude cannot access another browser Project or chat by itself.
If Plugins is unavailable, ask your facilitator. Keep working; setup help happens alongside the lab.

### Keep it safe

Use public organizational material without personal details, or the fictional practice pack supplied by the guide.
Clients, donors, volunteers and anyone you serve never go into Claude or your AI-Labs folder,
and neither do health or case details. Staff names in your everyday writing are fine.
Remove excluded information before sharing. Don't upload it for Claude to clean.

## Why this matters

Saved voice notes help Claude write more like your organization on the next job, too.

## Today, step by step

In Cowork or your browser, with the current **lab-guide** available, say:

```prompt
I'm ready to begin Lab 2.
```

Claude welcomes you, checks your saved work and guides you one question at a time. You don't need to read ahead.

It handles folders, missing lab files, voice notes, drafts and saving. You answer, choose your voice and approve changes.

Speak or type. Mute Zoom when dictating. Each person works in their own Claude session.
In the browser, Claude uses visible Project files or interviews you, then makes downloadable files where tools allow.
Downloads are not automatically saved to your computer or uploaded to your Project.

### What the conversation covers

1. **Your voice.** Claude reuses available material, interviews only for gaps and saves voice lines after your approval.
2. **Your piece.** Claude asks what you need, who will read it and any missing facts, then drafts in your approved voice.
3. **Your saved result.** Claude checks facts and voice, helps revise, saves and reopens the actual files.

These are the conversation's stages. Claude moves between them; you don't have to paste another command.

Working on an RFP? Tell Claude. It builds a sourced compliance matrix instead of a writing draft.

```done
Claude reopens the files it created. In the browser, they are ready to download; local saving remains pending. Practice stays labeled.
```

If time is short, say so. Claude saves and checks your voice work; finish the draft afterward in the same guided conversation.

## If you get stuck

```prompt
Help me continue Lab 2.
```

Claude checks where you actually got to and helps with the next missing result. It does not restart finished work.
No samples? Say “Use the practice pack.” BrightPath is fictional; its voice stays separate from your real organization's.
Files in a browser Project? Claude needs them shared in this session before it can reuse them.
Ask your facilitator for access help; use the practice pack while they help. No copying or rebuilding finished work.

## This week

| Level | Your next result |
|---|---|
| Keep Pace | Finish your own voice notes and one real piece. Review it before sending. |
| Ship It | Send an approved piece. Tell Claude to record the real send and measured time in your ship log. |
| Build Ahead | Make a second piece for another reader, or build an RFP compliance matrix. |

Tell the guide your level. Claude saves next steps in `TO-DO.md` without replacing existing tasks.
Practice route: before real work, say “Use our real voice.” Claude keeps practice files separate and interviews you for your voice.
Bring to Lab 3: one messy reporting input, report name and reader. Aggregate numbers and staff notes only; no individual client rows.
Or use the Lab 3 practice mess pack. The same privacy rule applies.
In Zoom chat: “When ___ happens, I will ___.”

## How Claude runs these steps

The current Lab Guide reads this kit first. The start prompt authorizes work within the current session’s actual access.
Cowork works in the connected AI-Labs folder. Browser tools create artifacts/downloads; they do not edit the computer or Project.
Treat straight/curly apostrophes, capitalization and punctuation variants of “I'm ready to begin Lab 2” as the same request.
Welcome: “Welcome. We’ll capture your voice, draft a useful piece, then check and save it. I’ll use what’s available here.”
Then use tools to inspect actual saved work and prepare missing lab assets. Explain each operation briefly before doing it.
Keep only one unanswered question at a time. Wait for the answer; reuse it instead of asking again.
Proceed through the stages without asking for another stage command. Pause for voice approval and decisions on draft changes.
Never send the participant to the worksheet or ask them to open Finder, create folders, move, rename or save files manually.
In Cowork, request only a genuinely missing folder grant. In a browser, continue with visible files, an interview or practice.
Do not send browser users to Cowork just to begin. Don’t claim a downloaded artifact is saved on the computer or in a Project.
If samples are missing, offer a spoken/typed interview or fictional practice; do not require manual document gathering.
Resume completed stages from actual saved progress. Don't overwrite existing drafts or treat placeholders as finished answers.
The three earlier work prompts remain optional shortcuts, not required steps.
Use actual file tools; never claim a write, reopen or check without successful tool evidence. Keep coaching short.

**Step 1:** Read existing `AGENTS.md` and permitted samples. Reuse substantive organizational answers already saved.
Ask only for missing facts or clarification, one question at a time. Never turn placeholders into invented answers.
In Cowork, prepare missing folders and kit assets with the guide helper. In a browser, use its session workspace. Preserve prior work.
Organize approved copies of available public mission, samples and outcomes under `Org-Brain`, preserving source facts.
Ask about audience, voice and never-say words. Propose specific voice notes with examples rather than generic adjectives.
After approval, save `Org-Brain/voice-notes.md` and update only “How we sound” in `AGENTS.md` with five key lines.
If AGENTS.md is missing, create a partial file with approved voice rules; label the remaining interview unfinished.
Reopen both files. For practice, use `Kits/MOCK-OrgBrain-Starter-Pack.md`; save under `Kits/Practice/Org-Brain`.
Save practice voice rules in `Kits/Practice/AGENTS.md`, preserving real privacy rules when available.
Keep BrightPath's voice out of real `AGENTS.md`. Label every practice draft fictional.

**Step 2:** Read saved instructions and approved voice notes. Ask for missing goal, reader, length and source facts.
Match the voice; don't reuse sentences or stories from samples. Never invent outcomes, quotes, people or commitments.
For an RFP matrix, quote each requirement and source location, match only documented evidence and mark unsupported rows as gaps.
Practice facts support practice work only. Never present them as the participant's facts.

**Step 3:** Review against sources and voice notes. Show questionable lines and let the participant choose changes.
Save the approved draft or matrix in `Outputs` with a meaningful name; preserve earlier versions of existing results.
Reopen the output, voice notes and actual `AGENTS.md` produced by your tools; confirm content, not merely file existence.
Browser: provide download links, ideally one bundle. If file creation is unavailable, show approved contents and mark export pending.
For practice, reopen its files under `Kits/Practice` instead; report rehearsal complete and real voice work unfinished.
If no draft exists, check and save only voice work. Report genuine gaps without claiming completion.
Record sends only after confirmation of a real send. A draft is not a ship-log entry.
For a requested fresh-session check, read these saved files again. The exact setup readback prompt remains:

```prompt
Read AGENTS.md first. What did I ask you to follow in this folder? Name the three rules that matter most.
```

Each returned rule must actually appear in the file. A fresh-session check remains pending until that session runs it.
Never send externally on the participant's behalf as part of these steps.
