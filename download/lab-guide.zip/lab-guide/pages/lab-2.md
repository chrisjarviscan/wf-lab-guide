<!-- Lab Guide 1.0.21 · Oct 12, 2026. Mirrored from the Lab 2 kit as published on Oct 12, 2026 (source cf9b7c5). Do not edit: rebuild instead. -->

# Lab 2: Writing and the org brain

[Participant Hub](https://wf-ai-labs.rw.institute/participant#lab-2) · Today’s win worksheet

Make Claude sound like your organization. Leave with saved voice notes and, if time permits, one real draft. Voice notes are written notes about your organization’s writing style, not an audio recording.

Claude handles files when its tools can; otherwise it provides complete files for you to save. You choose what sounds like you and check the facts.

## Choose your screen

Read the path for the screen you are using. Already using the current guide with your work available? Continue in that conversation.

### I'm using Claude in my browser

1. Open your **AI-Labs Project** in Claude and start or return to your work chat.
2. [Download the text guide](https://wf-ai-labs.rw.institute/lab-guide/lab-guide-chat.md). Add `lab-guide-chat.md` to this chat with the attachment button. Add your latest `AGENTS.md` and voice notes too, if you have them.
3. Check that the guide appears as an attachment. Ask **“Is the guide working?”** Claude should confirm the current version and that it can read the Lab 2 instructions.

Then say **“I'm ready to begin Lab 2.”** Claude leads one question at a time. Start with your writing style; a draft comes next if time permits.

**Keep your finished work:** save the approved files to your Project, then open them to check the contents. Downloading saves a local copy; it does not update Project files. Use the browser saving steps below. No Project or missing upload controls? See Help below.

### I'm using the Claude desktop app

1. [Download the guide ZIP](https://wf-ai-labs.rw.institute/lab-guide/lab-guide.zip). **Keep it zipped for upload.**
2. In **Customize → Skills**, choose **+ → Create skill → Upload a skill**, select the ZIP and enable **lab-guide**, where these controls are offered.
3. Open your work conversation. Ask **“Check and fix setup.”** If Claude requests folder access, choose your existing **AI-Labs** folder. Claude must name the files its tools can actually read, or explain what is missing. Installing the guide does not connect the folder.

Ask **“Is the guide working?”** Expect the current version and confirmation that Claude can read the Lab 2 instructions. Then say **“I'm ready to begin Lab 2.”**

**Keep your finished work:** with connected-folder tools, Claude saves and reopens the approved files. Confirm where they were saved. No folder access or Skills controls? See Help below; you can still begin the voice conversation.

## Save and continue on your screen

### Browser — keep a usable copy

Keep AGENTS.md, voice-notes.md and any approved draft. When a prompt names a path such as `Outputs/report.md`, use the filename `report.md` for the attachment; the folder name tells desktop users where it belongs. For the practice route, use `practice-AGENTS.md` and `practice-voice-notes.md` as attachment names and use those names in browser prompts. Never replace your real AGENTS.md or voice notes with a practice file. Local folders such as Outputs, Recipes and Workflows are optional organization for your downloads. Claude cannot read them just because you saved there.

Ask for each complete file as a separate download. If no download is available, ask for its full contents in a separate text block headed with the filename. Save `.md` files as plain text, without an extra `.txt` ending. A spreadsheet needs a real CSV or spreadsheet file; renaming `.xlsx` to `.csv` does not convert it.

In a Project, use **Save to Project** in the document panel if offered, or download then upload the approved file to Project files. Open the saved copy and check its contents before removing an older copy. A download alone does not update the Project. Without a Project, keep the latest files and attach them to the next chat. Before an intentional fresh-chat check, save first, then ask the new chat to read the files and quote a line you can check.

### Desktop — save and reopen

Claude saves approved work in the named folders only when its tools have access. Ask it to reopen the saved files and check them. Do not overwrite an earlier draft or existing instructions without your approval. When a step says “start fresh,” open a new work session on the same AI-Labs folder and read the saved files. If saving is unavailable, use the browser saving steps alongside this card.

**Interrupted?** Keep your current chat. Note the lab, step, latest filenames and next action. Resume there when possible; if you must start another chat, make those files available using your screen's steps above. Never count a promise to save as a saved file.

**A fresh chat is not a memory reset.** For a cold-read test, turn off Memory for that chat where offered before sending the first message. Ask Claude to use only the named files and verify its quotations against them. If you cannot isolate memory, treat the result as another review, not proof of an independent cold read.

**Browser wording for the shared prompts:** keep the learning request and safety limits. Replace a computer path with the attached filename. Replace “save in [folder]” with “provide the complete file named [filename] for me to save.” If you have no Project, “in this Project” means “attached to this chat.” Tell Claude which route you are using; it must not claim a folder write without file tools.

## Your Lab 2 path

We connect the guide together in the main room. Then Claude leads you through the work, one question at a time.

1. **Open the guide** — Use the browser or desktop steps above to add the current guide.
2. **Check it works** — Ask “Is the guide working?” Check the version, lab and time.
3. **Begin Lab 2** — Say “I'm ready to begin Lab 2.” Claude checks the work it can access.
4. **Find your voice** — Answer missing questions. Approve voice rules; save and check them using your screen’s steps.
5. **Draft your piece** — Give the job, reader and facts. Claude writes in your approved voice.
6. **Optional: try writing skills** — Both checks are already included. Download and upload the separate skills where offered. Ask “Show me before and after.”
7. **Check and save** — Judge the writing and verify facts. Approve; Claude saves and reopens the result.
8. **Choose what's next** — Choose your homework level. Claude records your plan and helps you continue.

You supply facts and make decisions. Claude handles file work with the access available in your session.
Short on time? Save voice work; finish the draft later. Use the saving steps for your screen below.

## Before you come

Use the path above for your screen. GitHub sign-in and Claude's GitHub connector are not needed. Keep your existing work.

### Two short checks

```prompt
Is the guide working?
```

Pass: the current guide version and the correct cohort time. Lab 2: Monday, October 5, 2026, 1:00–2:30 PM Eastern (noon–1:30 PM Central); Friday, October 9, 2026, noon–1:30 PM Eastern (11:00 AM–12:30 PM Central). Use the participant’s cohort; if unknown, show both.

```prompt
Check and fix setup.
```

Claude checks what is actually available in this conversation. It should name the first missing item and help you with it. See Help below if your screen differs.

### Keep it safe

Use public organizational material without personal details, or the fictional practice pack supplied by the guide.
Clients, donors, volunteers and anyone you serve never go into Claude or your AI-Labs folder,
and neither do health or case details. Staff names in your everyday writing are fine.
Remove excluded information before sharing. Don't upload it for Claude to clean.

## Why this matters

Saved voice notes help Claude write more like your organization on the next job, too.

## Today, step by step

In Cowork or your browser, with the current **lab-guide** available, say:

```prompt
I'm ready to begin Lab 2.
```

Claude checks available work and asks one question at a time. Answer, choose your voice and approve changes.
It handles missing lab files, voice notes, drafts and saving. No separate command for each stage.

Speak or type. Mute Zoom when dictating. Each person works in their own Claude session.
In the browser, Claude uses visible Project files or interviews you, then makes downloadable files where tools allow.
Creating a downloadable file does not put it in Project files. Downloading gives you a local copy; add it to your Project separately.

### What the conversation covers

1. **Your voice.** Claude reuses available material, interviews only for gaps and saves voice lines after your approval.
2. **Your piece.** Claude asks what you need, who will read it and any missing facts, then drafts in your approved voice.
3. **Your saved result.** Claude checks facts and voice and helps revise. With file tools, it saves and reopens the files. Otherwise it helps you save and reopen a retained copy, one action at a time.

### Optional: see a writing skill work

1. Download [Syntax Avoidance](https://wf-ai-labs.rw.institute/lab-guide/ai-syntax-avoidance.zip)
   and [Extended review](https://wf-ai-labs.rw.institute/lab-guide/ai-syntax-avoidance-extended.zip).
2. Where offered, open Claude’s Skills controls, upload both ZIPs and enable them. Keep this work chat.
3. Give Claude one permitted paragraph. Say:

```prompt
Show me before and after.
```

Compare the original and revision. Claude explains one change; you judge which sounds like your organization.
Facts and quotations stay intact. A strong paragraph may need no changes.
Both checks are already in the guide. Uploading teaches you to add a skill for use outside the labs.
Already installed, or no upload controls? Watch the demo and continue with the built-in checks.

Working on an RFP? Tell Claude. It builds a sourced compliance matrix instead of a writing draft.

```done
Your approved voice files have been saved and reopened. Claude checks files its tools can access. For downloads or manually saved text, you open your retained copy and confirm the approved contents. The guide states who checked each copy. Practice stays labeled. Sending is separate homework.
```

If time is short, say so. Claude saves and checks your voice work; finish the draft afterward in the same guided conversation.

## If you get stuck

### Help: update files already imported from GitHub

Already imported the guide from GitHub into a Project? After the repository changes, open that Project’s repository item and check the selected branch and files. Choose Sync or Sync now, where offered, and wait for it to finish. Then ask “Is the guide working?” and check the version. Sync refreshes the previously selected files and folders on that branch; a connected account alone does not refresh them. It does not update an uploaded ZIP or text attachment. If these controls are unavailable, use the current text guide when an update is needed and preserve your work. GitHub is optional.

### Help: no Project, missing controls or a different screen

- **No Project:** attach the text guide to a regular chat and begin there. Keep the full approved work and attach it again in each new chat. A Project is optional.
- **No Skills upload controls:** use the text guide attachment in your existing work chat. Keep ZIP packages zipped when using Skills upload.
- **No Cowork selector:** in unified Claude, stay in the same conversation. A Project with the guide added from GitHub, the text attachment and the ZIP upload all carry the same guide. Claude checks actual tools and permission.
- **No local-folder access:** Claude can use visible attachments or interview you. It creates downloads where tools allow. Follow the saving help under “Keep your work and return later”; do not treat a download as a Project update.
- **No file tools:** Claude shows the complete approved text and filename. Follow the plain-text saving steps below, or ask the facilitator before closing the chat. A save stays pending until you reopen and confirm the retained copy.
- **Uploads blocked:** ask the facilitator or your organization’s support team. Do not change security controls to continue.

```prompt
Help me continue Lab 2.
```

Claude checks where you actually got to and helps with the next missing result. It does not restart finished work.
No samples? Say “Use the practice pack.” BrightPath is fictional; its voice stays separate from your real organization's.
Files in a browser Project? Claude needs them shared in this session before it can reuse them.
Ask your facilitator for access help; use the practice pack while they help. No copying or rebuilding finished work.

## This week

| Level | Time | Your next result |
|---|---|---|
| Keep Pace | 30–45 minutes | Send one more real piece; improve a voice rule where the draft slipped. |
| Ship It | 1–2 hours | Finish, check and send today's real piece. Log the actual send and measured time. |
| Build Ahead | 3+ hours | Build a second reader's voice; send one real piece in each voice. |

Tell the guide your level. Claude saves next steps in `TO-DO.md` without replacing existing tasks.
Practice route: before real work, say “Use our real voice.” Claude keeps practice files separate and interviews you for your voice.
Bring to Lab 3: one messy reporting input, report name and reader. Aggregate numbers and staff notes only; no individual client rows.
Or use the Lab 3 practice mess pack. The same privacy rule applies.
In Zoom chat: “When ___ happens, I will ___.”
Claude helps you resume during the week. Say “Help me finish Lab 2.”
A draft, an actual send and readiness for Lab 3 are separate results. Claude checks the evidence before reporting each one.

## How Claude runs these steps

The current Lab Guide reads this kit first. The start prompt authorizes work within the current session’s actual access.
Inspect actual tools and permission. Connected-folder tools can edit the approved AI-Labs folder; session-only tools create downloadable files; text-only sessions use the saving fallback. Do not infer local access from browser or desktop alone. Project copies need an explicit update.
Treat straight/curly apostrophes, capitalization and punctuation variants of “I'm ready to begin Lab 2” as the same request.
Welcome: “Welcome. We’ll capture your voice, draft a useful piece, then check and save it. I’ll use what’s available here.”
Then use tools to inspect actual saved work and prepare missing lab assets. Explain each operation briefly before doing it.
Keep only one unanswered question at a time. Wait for the answer; reuse it instead of asking again.
Proceed through the stages without asking for another stage command. Pause for voice approval and decisions on draft changes.
Do the authorized file work your tools support. If a download, manual-save fallback or Project update requires the participant, guide it one action at a time with a visible success check. Use the recovery instructions below.
In Cowork, request only a genuinely missing folder grant. In a browser, continue with visible files, an interview or practice.
Do not send browser users to Cowork just to begin. Don’t claim a downloaded artifact is saved on the computer or in a Project.
If samples are missing, offer a spoken/typed interview or fictional practice; do not require manual document gathering.
Resume completed stages from actual saved progress. Don't overwrite existing drafts or treat placeholders as finished answers.
The three earlier work prompts remain optional shortcuts, not required steps.
Use actual file tools; never claim a write, reopen or check without successful tool evidence. Keep coaching short.

**Step 1:** Read existing `AGENTS.md` and permitted samples. Reuse substantive organizational answers already saved.
Ask only for missing facts or clarification, one question at a time. Never turn placeholders into invented answers.
In Cowork, prepare missing folders and kit assets with the guide helper. In a browser, use its session workspace. Preserve prior work.
Organize approved copies of available public mission, samples and outcomes under `Org-Brain`, preserving source facts.
Ask about audience, voice and never-say words. Propose specific voice notes with examples rather than generic adjectives.
After approval, preserve earlier versions and save `Org-Brain/voice-notes.md`.
Update only “How we sound” in `AGENTS.md` with five approved lines.
If AGENTS.md is missing, create a partial file with approved voice rules and the course's fixed privacy baseline.
Keep client, donor, volunteer, health, case and personnel details out; do not invent missing organizational answers.
Label the remaining interview unfinished. A partial file is usable for this exercise, not a completed organizational interview.
Reopen both files. For practice, use `Kits/MOCK-OrgBrain-Starter-Pack.md`; save under `Kits/Practice/Org-Brain`.
Save practice voice rules in `Kits/Practice/AGENTS.md`, preserving real privacy rules when available.
Keep BrightPath's voice out of real `AGENTS.md`. Label every practice draft fictional.

**Step 2:** Read saved instructions and approved voice notes. Ask for missing goal, reader, length and source facts.
Match the voice; don't reuse sentences or stories from samples. Never invent outcomes, quotes, people or commitments.
During the writing stage, offer the skill demo one action at a time. Preserve writing time; do not require another start command.
Explain that both checks are included already, then offer the two download links above for optional standalone installation.
Only the participant can use the app's upload/enable controls. Do not claim installation without actual confirmation.
If already installed, unavailable or time is short, continue using the built-in checks; no bypass or purchase required.
For “Show me before and after,” reuse a visible permitted paragraph, or ask for one missing source.
Preserve the original, apply base syntax review then extended craft review, and show both with one concrete explanation.
Use approved organizational voice. Preserve source facts, uncertainty, quotations and required language; do not invent detail.
An unchanged strong paragraph is a valid result. Let the participant judge; save revisions only after approval.
For an RFP matrix, quote each requirement and source location, match only documented evidence and mark unsupported rows as gaps.
Practice facts support practice work only. Never present them as the participant's facts.

**Step 3:** Trace every factual claim to a permitted source. Flag unsupported comparisons, causal claims and conflicting sources.
Do not choose between conflicting figures without clarification. Show questionable lines and let the participant decide changes.
Ask them to read the draft aloud and judge whether it sounds like them. Recheck facts and voice after revisions.
For a matrix, show up to three requirement/evidence rows beside their exact RFP quotes and locations, one at a time.
Ask the participant to verify each pairing; lacking evidence stays a gap, never a compliant claim.
Offer to retain a useful correction as a new instruction. Show the exact change and save only after approval.
Keep existing rules. Save the successful brief, without invented facts, under Recipes if the participant wants to reuse it.
Save the approved draft or matrix in `Outputs` with a meaningful name; preserve earlier versions of existing results.
Reopen the output, voice notes and actual `AGENTS.md` produced by your tools; confirm content, not merely file existence.
Browser: provide download links, ideally one bundle. If file creation is unavailable, show approved contents and mark export pending.
For practice, reopen its files under `Kits/Practice` instead; report rehearsal complete and real voice work unfinished.
If no draft exists, check and save only voice work. Report genuine gaps without claiming completion.
Record sends only after confirmation of a real send. A draft is not a ship-log entry.
Ask for the item, send date, audience group and measured old/new minutes, one question at a time; never estimate missing values.
At the guided weekly close, let the person choose the original homework level above and save their plan under “Before Lab 3”.
Readiness for Lab 3 requires the person's real voice notes, corresponding approved AGENTS rules and a confirmed-send log entry.
If the interview, real voice, verified file export or measured times are unfinished, name those gaps separately.
For verified session files, say “Ready to download”. Local saving or Project updating stays unconfirmed until tools verify it or the participant confirms opening the retained copy. State which kind of evidence you have.
Without file creation, show approved complete contents and use the plain-text saving fallback below. Keep saving pending until the participant confirms the reopened copy; describe it as participant-confirmed, not a local save verified by Claude’s tools.
For a requested fresh-session check, read these saved files again. The exact setup readback prompt remains:

```prompt
Read the current AGENTS.md that you can access. Use that file, not memory. What did I ask you to follow? Name the three rules that matter most.
```

Each returned rule must actually appear in the file. A fresh-session check remains pending until that session runs it.
Never send externally on the participant's behalf as part of these steps.

## Keep your work and return later

Voice notes are written notes about your organization’s writing style, not an audio recording.
`Org-Brain` is the folder for reusable information about your organization.
An RFP compliance matrix is a table matching each requested requirement to supporting evidence or a visible gap.

Browser: open AGENTS.md in the right-hand document panel. If Save to Project is available at the top right, choose it and select your AI-Labs Project. Otherwise, download AGENTS.md, open that Project, and upload the file to its Project files. Button names and availability may vary. Confirm AGENTS.md appears in Project files and open it to check the approved text before starting a fresh chat inside that Project for the readback. Downloading alone does not add a file to Project files. If replacing an older copy, check the new copy before removing the old one. No Project? Keep the complete file and attach it in each new chat; do not assume Claude remembers it.

Claude should do every file operation its tools and your permissions allow. Downloading a file or adding it to Project files may still need your action. The guide gives one action at a time and waits for your confirmation.

- With connected-folder tools: Claude writes and reopens the approved files in your existing AI-Labs folder. Keep the desktop app open while Claude needs its connected files.
- With downloadable files: open each offered file and check its contents. Download the approved bundle. Open the downloaded copy and confirm you can see your approved voice rules. Only then is your own copy confirmed saved. If you use a Project, add the new files there and check the updated copy before removing any older copy.
- Without file tools: Claude shows the full approved text with its filename, one file at a time. Save that text in a plain-text editor. On Windows, choose All files and name it exactly `AGENTS.md`; on Mac, choose Format → Make Plain Text before saving. For `Org-Brain/voice-notes.md`, use the `Org-Brain` folder in AI-Labs. Open the saved file and check it contains your approved text. If you cannot do this, ask the facilitator for saving help before closing the chat. This is a pending save, not completed file work.

Before stopping, ask: “Help me pause here.” Claude supplies a short resume note naming the approved files, where they are, the last completed step, any unsaved text, and the next action. It includes no restricted information. Save the note with your work, or keep this conversation available until a facilitator helps. A summary does not replace unsaved full file contents.

To return in a new chat, attach the current guide, your latest `AGENTS.md`, `Org-Brain/voice-notes.md`, and any draft or next-step note. Ask: “Read these files and help me continue Lab 2 from the first unfinished step.” Claude must read what is actually attached before claiming progress. No Project is required.

For Lab 3, add its kit and your permitted reporting input or fictional mess pack to the new conversation. If you use a Project, update its copies explicitly; if you do not, attach the same files in each fresh review chat. Run the readback check against the actual attached AGENTS.md. A new chat alone does not prove memory is off; turn Memory off where offered for the independent check, and compare each quoted rule with the file.

If the guide cannot be installed or attached, attach the Lab 2 Markdown kit linked from the participant hub and say: “Read this kit, including How Claude runs these steps. Guide me through Lab 2 one question at a time. Check your actual file tools, ask before saving voice changes, and never send anything for me.” Confirm Claude can read the kit before beginning. If attachments are blocked, ask the facilitator to guide the exercise; the short start phrase alone does not contain the lab instructions.

## What counts as finished

The live lab’s minimum is your approved written voice notes and five approved “How we sound” rules saved and reopened. A partial AGENTS.md must still show unfinished interview sections. A real draft or RFP table is the next goal when time permits. Fictional practice is a rehearsal, not your organization’s completed voice work.

A file ready to download still needs the participant’s download/open check. A participant-confirmed local save is not a tool-verified local save. Report these separately and accurately.

Sending is a separate homework action that you decide and perform after review. Claude does not send for you. Record only real, confirmed sends. Missing measured times must stay missing; never estimate them. Report the live lab’s saved work separately from remaining homework and timing gaps.
