<!-- Lab Guide 1.0.5 · Oct 5, 2026. Mirrored from the Lab 1 starter file as published on Oct 5, 2026 (source 5b4afb4). Do not edit: rebuild instead. -->

# Ship log
One line for each thing you send with Claude's help: the date, what it was, who it went to (a group like "board" or "volunteers", never the name of a client, donor or volunteer), old way __ minutes, new way __ minutes, both timed on a stopwatch.
