<!-- Lab Guide 1.0.21 · Oct 12, 2026. Mirrored from the Lab 1 starter file as published on Oct 12, 2026 (source cf9b7c5). Do not edit: rebuild instead. -->

# Ship log
One line for each thing you send with Claude's help: the date, what it was, who it went to (a group like "board" or "volunteers", never the name of a client, donor or volunteer), old way __ minutes, new way __ minutes, both timed on a stopwatch.
