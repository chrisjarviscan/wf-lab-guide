<!-- Lab Guide 1.0.28 · Oct 16, 2026. Mirrored from the Lab 4 kit as published on Oct 16, 2026 (source 0bc91c1). Do not edit: rebuild instead. -->

# Lab 4: Data, clean and extract

You'll leave with a spreadsheet cleaned by Claude, a change log you checked, the organization names back in, and a cleanup recipe. If a word is new to you, it's in Words we use (see hub-words.md). The moves behind every prompt are in Ways to ask Claude (see hub-ways.md).

## Choose your screen for Lab 4

**Already started?** Keep your existing Project, chat or AI-Labs folder. Do not recreate it or reinstall a working guide. The learning steps below are shared; only file access, saving and restarting differ. Check the tools actually available: if your browser session has approved folder tools, use the connected-folder instructions. If your desktop chat has no folder tools, use the attachment instructions.

### Browser — open and attach

Open your AI-Labs Project and work chat, if you have one. Make these files available: AGENTS.md and the kit; add only the checked, swapped CSV after step 3. Never attach the original export, the key or the sheet with names restored. Add files to **Project files** for use across chats, or attach them to this chat. Ask Claude to name what it can actually read before starting.

**No Project?** Use a regular chat. Attach the same permitted files. Keep complete copies of the results yourself. Every time a step says “start fresh,” open a new chat and attach the latest files that step names. A previous chat's attachments are not a substitute. If attachments are unavailable, paste the complete permitted text with each filename above it; never paste a confidential original or key.

### Desktop — connect your folder

Open a work session with folder tools (Cowork where offered) and choose your existing **AI-Labs** folder itself. Put this lab's kit and practice files in **Kits**. Use only permitted material. Ask Claude to name files it can actually read. A desktop chat without folder access follows the browser file steps; installing a skill alone does not connect a folder.

## Save and continue on your screen

### Browser — keep a usable copy

Keep the cleaned CSV with placeholders still in, its change log, your cleanup recipe, AGENTS.md and ship-log.md. When a prompt names a path such as `Outputs/report.md`, use the filename `report.md` for the attachment; the folder name tells desktop users where it belongs. Local folders such as Outputs, Recipes and Workflows are optional organization for your downloads. Claude cannot read them just because you saved there.

Ask for each complete file as a separate download. If no download is available, ask for its full contents in a separate text block headed with the filename. Save `.md` files as plain text, without an extra `.txt` ending. A spreadsheet needs a real CSV or spreadsheet file; renaming `.xlsx` to `.csv` does not convert it.

In a Project, use **Save to Project** in the document panel if offered, or download then upload the approved file to Project files. Open the saved copy and check its contents before removing an older copy. A download alone does not update the Project. Without a Project, keep the latest files and attach them to the next chat. Before an intentional fresh-chat check, save first, then ask the new chat to read the files and quote a line you can check.

### Desktop — save and reopen

Claude saves approved work in the named folders only when its tools have access. Ask it to reopen the saved files and check them. Do not overwrite an earlier draft or existing instructions without your approval. When a step says “start fresh,” open a new work session on the same AI-Labs folder and read the saved files. If saving is unavailable, use the browser saving steps alongside this card.

**Interrupted?** Keep your current chat. Note the lab, step, latest filenames and next action. Resume there when possible; if you must start another chat, make those files available using your screen's steps above. Never count a promise to save as a saved file.

**A fresh chat is not a memory reset.** For a cold-read test, turn off Memory for that chat where offered before sending the first message. Ask Claude to use only the named files and verify its quotations against them. If you cannot isolate memory, treat the result as another review, not proof of an independent cold read.

**Browser wording for the shared prompts:** keep the learning request and safety limits. Replace a computer path with the attached filename. Replace “save in [folder]” with “provide the complete file named [filename] for me to save.” If you have no Project, “in this Project” means “attached to this chat.” Tell Claude which route you are using; it must not claim a folder write without file tools.

## Before you come

If your ready check at the end of Lab 3 said you're ready for Lab 4, your saved work is ready. Use the screen instructions above to make these files available:

- **Desktop:** save the Lab 4 files into `AI-Labs/Kits`. **Browser:** download these files and add them to Project files or attach them to your work chat:
  - this kit, `KIT-Lab4-Data-Clean-Extract.md`
  - the practice sheet, `MOCK-Benevity-Export-Messy.csv`
- Save the practice key, `MOCK-Placeholder-Key.csv`, in a folder you choose outside `AI-Labs`, where your organization keeps confidential records, never in `Kits`. That's your key folder, for your own key too. Keys never go near Claude, so you move them by hand.
- Choose your material. Both take the same steps today.
  - Your own: your recurring spreadsheet's tab exported as a `.csv` file, every column unhidden, saved outside `AI-Labs`, plus one month's total from your system and how long cleaning it takes by hand.
  - The practice sheet: a fictional funder's grants export, already in `Kits`.
- Optional, and it saves time in the room: start your key at home. In your key folder, list each organization name from your sheet's Organization column once, by hand. Nothing here goes near Claude.
- In step 1 you check your column headings, the top row only, with Claude. If a heading names an organization, change it to its `ORG-01` placeholder first.
- Clients, donors, volunteers and anyone you serve never go into Claude or your AI-Labs folder, and neither do health or case details. Staff names in your everyday writing are fine. A spreadsheet adds a stricter rule:
  - Delete every column that names or identifies a person, staff included: names, addresses, phones, emails, birth dates, ID numbers. These are the red columns.
  - Delete notes and comments columns too. Names hide in them, and a header can't show you what's in the cells.
  - If each row is one person or one visit, turn it into counts first, or use the practice sheet. Health, substance-use and immigration services always do this.
  - Organization names get placeholders in the form `ORG-01`. No other placeholder format is used.
  - Keep programs, sites, dates, counts and amounts. If you're unsure about a column, delete it.
- Setup check: open a Cowork session on `AI-Labs` itself and paste this. Claude will look in every folder for a file with "key" in its name, open nothing, and end with one line.

  ```prompt
  Check my AI-Labs folder, and don't change anything. Look at the name of every file in every folder, without opening any. Treat each file with "key" anywhere in its name, in capitals or not, as a placeholder key. Keep your reply short, and end it with exactly one of these lines: "No placeholder key in AI-Labs." or "Move out of AI-Labs:" followed by the names of all those files.
  ```

  ```done
  Claude's last line says "No placeholder key in AI-Labs." If it says "Move out of AI-Labs:", move each file it names to the place you chose for your key, by hand, and check again.
  ```

  - Why this way: Claude reads every file name, even in folders you'd skip, and the fixed last line answers at a glance; moving a key stays by hand because the key never goes near Claude. It uses "end with one clear line". The same check finds any file with "draft" in its name before a board packet goes out.
  - If it doesn't work: if Claude can't find your folder, check that you opened `AI-Labs` itself. If it names a file that isn't a key, like `key-messages.md`, rename that file without "key". If you missed Lab 3, its kit is on the participant page (see hub-labs.md). Come anyway, and to sort it out sooner, email Nichole Giller at nichole@realizedworth.com with the step you're on.
  - Browser: look through your `AI-Labs` folder yourself for any file with "key" in its name, and move it out. Check Project files and current attachments too. If a key was uploaded, stop, remove it, and tell your facilitator; deleting it does not undo the exposure.

## Why this matters

Your board and funder reports start from the spreadsheet you rebuild every month. Behind its rows are people and partners who never agreed to go into an AI tool, so people stay out and partners go in as placeholders. Claude cleans fast and can quietly merge two rows that only look alike. Your own count and a checked change log show whether it did.

## Today, step by step

In your breakout room, each of you works on your own computer, with your own Claude, copy and key, your colleague included. If your facilitator asks to see your screen, never show your key folder. Time steps 1 to 7 on a stopwatch.

1. **Save a copy and check your headings.** Save a copy in your key folder, so the original stays untouched. Delete any red or notes column, and change any heading that names an organization to its `ORG-01` placeholder. Then open a new chat in Claude and check your headings, the top row only. Keep this copy outside `AI-Labs` and out of all Claude uploads. “Headings clean” checks only the top row; it does not make the sheet safe. Do not move or upload the sheet until step 3 is complete. You delete columns by hand because the data has to be safe before anything goes near Claude, and the headings are the only part of your sheet Claude sees in this step.
   - Your own sheet: keep one month, about 50 rows.
   - Practice sheet: copy `Kits/MOCK-Benevity-Export-Messy.csv` into `Working`. It holds no personal data, so skip the heading check.
   - More: about 50 rows is few enough to check every change; keep the month your system total covers. If that month runs well past 50 rows, keep all of it, or keep 50 and skip the system-total check in step 7, since that total covers rows you cut. To copy only the top row, click the row number 1 so nothing else is selected, and never paste a row below it. Start your key next, in step 2.

   Claude will read only your headings, list any that could point to a person, and end with one line.

   ```prompt
   Below are the column headings from a spreadsheet, the top row and nothing else. Which of these columns could point to one person, such as names, addresses, phone numbers, emails, birth dates, ID numbers, or notes and comments? Also flag any heading that is itself a person's name or an organization's name; a plain heading like "Organization" is fine. Don't ask for the file, and don't guess at what is in the cells. Keep your reply short. The last line of your reply must be exactly one of these two lines, with nothing after it: "Headings clean." or "Delete these columns:" followed by the headings.

   Paste the top row here:
   ```

   ```done
   Claude's last line says "Headings clean." If it says "Delete these columns:", delete each one it names from your copy, or change a heading that names an organization to its `ORG-01` placeholder, copy the top row again and run it again. This checks headings only. It can't see the cells, which is why the notes columns go first.
   ```
   - Why this way: the headings are the only part of your sheet Claude sees, so nothing personal goes in, and the fixed last line answers at a glance. It uses "end with one clear line". The same move fits any sheet you are about to share.
   - If it doesn't work: if Claude asks for the file, say no and paste the top row only. If you pasted more than the top row, delete that chat, delete any column that names a person from your copy, and tell your facilitator; at home, email Nichole Giller at nichole@realizedworth.com. If Claude flags a heading that isn't personal, like Site Name, keep the column, tell Claude why and run it again.
   - Browser: use a new chat outside your Project, so Claude reads nothing but the top row you paste.

   2. **Make your placeholder key.** A column of organization names, like partners or grantees, is yellow: its names get placeholders, and the key lets you put them back. You make the key by hand because it never goes near Claude. In your key folder, start a sheet with three columns: Placeholder, Name in the sheet, Swap back to. Number the names ORG-01, ORG-02 and on; two spellings of one organization share a placeholder.
   - Your own sheet: put "key" in the file name, like `volunteer-hours-key.csv`, so the key check spots it.
   - Practice sheet: use `MOCK-Placeholder-Key.csv`.
   - More: every other column is green and stays as it is. To list each name once, copy the yellow column into the key's "Name in the sheet" column and delete the repeats; keep every spelling, since each gets its own row. "Swap back to" holds the spelling you want in the finished sheet. If your sheet names no organizations, skip the key and the swap, and still count in step 3. Next month, open this key again and give only new organizations the next free number, so each placeholder keeps meaning the same organization and your recipe's rules still fit.

   3. **Swap the names, then count.** You swap and count by hand, because the key never goes near Claude and a check on Claude can't come from Claude. In your copy's yellow columns, find and replace each name with its placeholder, ticking the whole-cell option. Filter each yellow column: any value but a bare placeholder is a missed name, so add it to the key and swap it. Check the whole copy by hand: no personal or notes columns, no person-level rows, and every organization name replaced. Only after that check, save the de-identified copy in `Working` on desktop, or upload it in the browser, as a `.csv`, like `volunteer-hours-swapped.csv` (practice: `grants-swapped.csv`). Write down its data row count (last row number minus 1) and the total of the column you report on (practice: Amount). Then type "saved" in the Zoom chat so your facilitator can see who needs a hand.
   - More: the whole-cell option is often called "Match entire cell contents". Add any amount typed as words into your total. Saving as a `.csv` can change how dates look or drop leading zeros from ID numbers, so compare a few cells with the original before you blame Claude for a change.

   4. **Run your brief on 10 rows.** Ten rows are few enough to check by eye, so a missing rule shows up early. Write your brief from "Your brief to Claude", whose must-have lines ask for a change log: each change, with its row and reason. Start fresh (in the desktop app, a new Cowork session on `AI-Labs` itself; in the browser, a new chat inside your AI-Labs Project, or a new regular chat with the latest required files attached) and paste it.

   ```done
   Claude saves the cleaned sheet and change log in `Outputs`, shows the log for the first 10 rows and waits for your yes. A reply of only a row number means a name got through: see below.
   ```

   - Why this way: a bare "clean this up" leaves no record of what changed. The change log lets you check each change now, and next month, if you tweak the recipe and forget you did, it shows which change moved your numbers. It uses "only after I say yes", so nothing past row 11 changes until you've checked. The same move fits renaming a folder of grant reports or program flyers.
   - If it doesn't work: if Claude asks about a blank, answer it and add your answer to the brief. If it replied with only a row number, delete that chat and anything it saved in `Outputs` (in the browser, the uploaded file too). Open the swapped file from `Working` and find the name in that row. Give an organization its placeholder (and add that spelling to your key) or delete a person's name, then check the rest of its column. Save it and start fresh. Tell your facilitator; at home, email Nichole Giller at nichole@realizedworth.com.
   - Browser: before you paste, upload the swapped file to your Project and use file creation if your account offers it. Download the files under the names your brief gives. For CSV, use the spreadsheet app’s Save As or Export CSV command; do not just rename an .xlsx file. Keep local copies in `Outputs` if helpful, and paste a log shown as text into a plain text file with its name. Next month, upload the new, checked swapped CSV to Project files using the same filename, such as `volunteer-hours-swapped.csv` (practice: `grants-swapped.csv`). Open the newly uploaded copy and verify its reporting month, row count and total against your checked local CSV. Only then remove the obsolete Project copy. Before asking Claude to clean it, confirm that Project files contains just the verified current copy under that filename, start a new chat inside the Project, and name that exact file. If you cannot tell the copies apart, stop and ask your facilitator; do not delete either or run the cleanup yet.
5. **Check every change in those 10 rows.** Catching a wrong change now costs one new rule. Check each judgment call against the swapped file. Look at each date that could read two ways, like 3/4/2025, and confirm blanks stayed blank. You check by hand because a check on Claude can't come from Claude.
   - More: a judgment call is a change Claude decided for one row, like a filled blank; a format rule changes a whole column the same way, like taking the $ signs out of Amount.
   - If it doesn't work: if a change is wrong, add a rule to your brief, placeholders only, and run step 4 again.
6. **Clean the rest.** Once 10 rows are right, the rules can run on every row. Paste this in the same chat. Claude will clean the other rows the same way, add them to both files and show you the change log.

   ```prompt
   Yes. Clean the other rows the same way and add them to both files. Then show me the change log so I can check it.
   ```

   ```done
   Both files in `Outputs` now cover the whole sheet, and Claude shows the change log or its new lines. Check new judgment calls as in step 5.
   ```

   - Why this way: the rest runs on rules you've already checked, and the log comes back to you before anything depends on it. It uses "show me so I can check". The same go-ahead fits reformatting a year of program dates in an event calendar, or tidying county names in a service-area table, once the first ten look right.
   - Browser: save the finished files in `Outputs` over the 10-row versions, with the same names.
7. **Reconcile, then put the names back.** Your numbers before and after should differ only by what the log explains. Open the cleaned sheet from `Outputs`, count its data rows as in step 3, add up the same column, and match each difference to a log line. Then re-identify: save a copy in your key folder and swap each placeholder there for its "Swap back to" name. You reconcile and swap back by hand, because Claude's totals can't check Claude and the key never goes near it.
   - Your own sheet: compare your system's total too.
   - Practice sheet: the funder's records show 57 grants, $1,255,000.

   8. **Save your cleanup recipe.** Next month starts from every rule you added today. Paste this in the chat where you ran the brief. Claude will save the brief, word for word, in `Recipes` and tell you the file name.

   ```prompt
   Save the brief we just used, word for word, in Recipes. Name the file for the sheet, ending in -cleanup.md, like Recipes/volunteer-hours-cleanup.md.
   ```

   ```done
   Claude names the file it saved, and it's in `Recipes`, ending in `-cleanup.md`.
   ```

   - Why this way: next month, a saved brief runs rules you've already checked, and you skip writing it again. It uses "word for word", so every rule you added today survives. The same move keeps the brief behind a monthly board dashboard or a quarterly grant report.
   - Browser: save the Notepad or TextEdit file you wrote the brief in as a plain text file named for the sheet, like `volunteer-hours-cleanup.md`, in `Recipes` (Windows Notepad: choose "Save as type: All files"; Mac TextEdit: choose Format, then Make Plain Text). Then upload it to your Project.
9. **Get an outside read of your recipe (5 minutes).** Next month's session will read only your recipe. Start fresh (in the desktop app, a new Cowork session on `AI-Labs` itself; in the browser, a new chat inside your AI-Labs Project, or a new regular chat with the latest required files attached) and paste this with your sheet's short name in both blanks. Claude will read your recipe and change log, change nothing, and quote each rule that reads two ways, each call with no rule, then the rule most worth keeping.

   ```prompt
   Read Recipes/___-cleanup.md and Outputs/___-change-log.md. Don't change any file, and don't open any file with "key" in its name. Read the recipe as someone who will run it next month on a new export and wasn't here today. Quote every rule that could be read two ways, and every judgment call in the change log that no rule in the recipe covers, and say why in one line each. If any line names an organization or a person instead of a placeholder like ORG-01, give only its line number, never the name. Then quote the one rule most worth keeping. End your reply with one line on its own: "Rules to check:" and how many you found.
   ```

   ```done
   Claude quotes rules that read two ways, calls with no rule and the rule most worth keeping, and its last line says "Rules to check:" and a number. You've decided each one: add a rule, reword one or leave it.
   ```

   - Why this way: the chat that wrote your recipe knows what you meant, so its rules look clear to it. A fresh session reads only the recipe and the log, as next month's will, and a call Claude made once with no rule can go the other way next time. You decide each one by hand, because which rules fit your sheet is a judgment call. It uses "start fresh from your files" and "end with one clear line". The same read works on any procedure a colleague will follow without you.
   - More: open your recipe in `Recipes` with Notepad or TextEdit, make each change, placeholders only, and save. If Claude quotes none, you're done; if it quotes many, start with the first three. If the room runs out of time, do this after the lab.
   - If it doesn't work: if Claude gives a line number in place of a name, your recipe names someone. Open it, put the placeholder in place of an organization or delete a person's name, save it, and tell your facilitator.
   - Browser: upload today's change log to your Project if it isn't there yet. Then, in a new chat inside your AI-Labs Project, paste the same prompt with "the cleanup recipe and change log in this Project" in place of "Recipes/___-cleanup.md and Outputs/___-change-log.md". After you change the recipe, upload the new file and open and verify the new Project copy before removing the older one.
   - **Room:** near the end of room time, your facilitator calls a round: each of you reads aloud one rule from your recipe, placeholders only, 20 seconds each. Not there yet? Read one limit from your brief, or pass. Hear a rule that fits your sheet? Note it and add it by hand after the lab.
10. **Save what you learned (2 minutes).** Every lab ends this way, so your folder gets a little better each week. Paste this in the chat where you did most of today's fixing. If you ran step 4 more than once, that chat can't see the earlier fixes, so add a line after the prompt saying what you changed today. Claude will suggest up to three lines for `AGENTS.md` from today's fixes and wait for your yes on each one.

    ```prompt
    Before we stop, suggest up to three lines to add to AGENTS.md from what we fixed today, so you get it right next time without being told. Don't include the name of any client, donor or volunteer. Show me the lines, and change AGENTS.md only after I say yes to each one.
    ```

    ```done
    You've said yes or no to each suggested line, and `AGENTS.md` holds only the ones you agreed to.
    ```

    - Why this way: it uses "only after I say yes" from Ways to ask Claude (see hub-ways.md), so nothing changes in the file Claude reads first until you've read the new lines.
    - Browser: paste the same prompt, then add the lines you agree with to `AGENTS.md` in Notepad or TextEdit. Upload the new `AGENTS.md` and open and verify the new Project copy before removing the older one.

## Your brief to Claude

Copy these questions into Notepad or TextEdit and replace each with your own answer. Name organizations only by placeholder, like ORG-03, because the brief goes to Claude.

> **The goal and why it matters.** Which sheet, and who uses the clean version?
>
> **The files to use.** Which file in `Working` is today's?
>
> **What done looks like.** How should each column look when it's clean?
>
> **The limits.** What must never change, and which blanks must stay blank?

- More: example answers for the practice sheet. For your own, answer the same way, one short line for each column you want changed.
  - **The goal and why it matters.** Clean Working/grants-swapped.csv, a funder's grants export, so our grants team can report from it this quarter. The organization names in it are placeholders.
  - **The files to use.** Read AGENTS.md first, then use Working/grants-swapped.csv and nothing else.
  - **What done looks like.** Dates written like 2024-04-05, so they sort in order. Amounts as plain numbers, with no $ sign or commas. One spelling for each program area.
  - **The limits.** Grant IDs, counties and statuses never change.

End with these must-have lines, word for word, with the short name your swapped file uses in both blanks, like volunteer-hours (practice: grants).

> Before you save anything, read every cell. If any cell looks like a person's name, save nothing, and reply with only its row number, never the name.
>
> Save the cleaned sheet as Outputs/___-cleaned.csv, same columns in the same order, and the change log as Outputs/___-change-log.md. Don't change the file in Working, and don't open any file with "key" in its name.
>
> The change log starts with the data row count before and after, then one line per judgment call (row, column, before, after, reason), then one line per format rule. Use my spreadsheet's row numbers, with the header as row 1.
>
> Placeholders like ORG-01 stay exactly as they are. Dates in the file are month/day/year. Delete a row only if it matches another row in every column. Blanks stay blank and get listed, unless other rows make the answer certain; then say which rows. Clean only: no analysis, no totals, no guessing.
>
> Do the first 10 rows, then stop and show me the change log so I can check it. Do the rest only after I say yes.

Next month, do steps 1 to 3 by hand, saving over last month's swapped file. Start fresh as in step 4 and ask Claude to follow your recipe, 10 rows first, naming the new files in `Outputs` by month.

## Check it before it ships

Use the lines that apply to what you're sending.

- [ ] You read every line, and you'd put your name on it.
- [ ] Every name, number, date and claim ('more', 'grew', 'because') traces back to your files.
- [ ] Where your files disagree, the draft flags it.
- [ ] Nothing from the "never goes in" list went into Claude.
- [ ] Read aloud, it sounds like your organization, with nothing from your never-say list.
- [ ] Your second chair has read it in a fresh chat, and you've settled its top three findings.
- [ ] The row count and the total reconcile, and the change log explains every difference. (new this week)

## If you get stuck

The table covers the likeliest problems this week. For anything else, ask Claude first. In Cowork, paste this and fill in the two blanks:

```prompt
Read Kits/KIT-Lab4-Data-Clean-Extract.md. I'm on this step: ___. Here's what I see: ___. What should I do next? Answer in three short steps.
```

In the browser, paste the step from this page instead of the file name. If Claude's answer doesn't get you moving, ask your room's facilitator. Between labs, email Nichole Giller at nichole@realizedworth.com with the step you're on.

| What you see | What to try |
|---|---|
| **Wrong output:** rows merged, a blank turned into a zero, or 3/4/2025 read as April 3 | Add a limit against it, like "Blank hours stay blank," then start fresh and run it again. |
| **Factual error:** your numbers don't reconcile | Find the log line for each difference. If none explains one, ask Claude which rows changed that column, then check them. |

## This week

Choose one level. You and your colleague can choose different ones, and you can switch levels any week.

| Level | Time | What you do | What you'll have |
|---|---|---|---|
| **Keep Pace** | 30 to 45 min | Your own sheet through steps 1 to 8, with someone at your organization checking the headers first, 10 rows first. Send it, names back in, to whoever uses it | A cleaned sheet sent |
| **Ship It** | 1 to 2 hours | Keep Pace on a bigger sheet, timed against your by-hand minutes | A timed sheet sent |
| **Build Ahead** | 3 hours or more | Ship It, plus a recipe for a second sheet, and send that one too | Two sheets sent |

If you used the practice sheet today, answer the brief's questions for your own sheet first.

Write your plan in the Zoom chat before you leave: When ___ happens this week, I will ___. For example: When next month's export lands, I will swap the names and run my recipe, 10 rows first.

Before you leave, add the week to your to-do list. In Cowork, paste this with your level filled in. Claude will add your homework and the Lab 5 bring list to `TO-DO.md` as unticked items and change nothing else.

```prompt
My homework level this week is ___. Add it and the Lab 5 bring list from Kits/KIT-Lab4-Data-Clean-Extract.md to TO-DO.md, as unticked items under a heading "Before Lab 5". Don't change anything else.
```

```done
`TO-DO.md` has a heading "Before Lab 5" with your homework and the bring list under it.
```

- Why this way: it uses "change only what I name" from Ways to ask Claude (see hub-ways.md), so your list gains this week's items and keeps everything else as you left it.
- Browser: add "Before Lab 5", your level and the bring list to `TO-DO.md` yourself.

Bring to Lab 5: the meeting your next deck is for (who will be in the room, what they're deciding, and when), and the numbers for it: today's cleaned sheet with its placeholders still in, or another sheet prepared the same way. Or choose the practice set in the Lab 5 kit, written for a funder's quarterly committee; the steps are the same.

Ship log: one line in `Outputs/ship-log.md` for everything you send, with old-way and new-way stopwatch minutes. For who it went to, give a group like "donors" or "board", never a person's name. In Cowork, paste this when something goes out; in the browser, add the line by hand. Claude will ask you what it was, the date, who it went to and both stopwatch times, then add one line to the log.

```prompt
Add a line to Outputs/ship-log.md for the item we just sent. Ask me what it was, the date, who it went to (a group like "board", never a person's name), and my old-way and new-way stopwatch minutes. Don't guess any of them.
```

```done
Claude asked you what it was, the date, who it went to and both times, then added one line to `Outputs/ship-log.md`.
```

- Why this way: it uses "ask me, don't guess" from Ways to ask Claude (see hub-ways.md), so every number in your log is one you measured.

When your homework is done, check you're ready for Lab 5. In Cowork, paste this. Claude will look through your folder without changing anything or opening any key file, and end with one line: ready, or the first thing missing or misplaced.

```prompt
Check my AI-Labs folder, and don't change anything. Look for a recipe in Recipes whose name ends in -cleanup.md, a change log in Outputs whose name ends in -change-log.md, and at least one entry in Outputs/ship-log.md below the line that starts "One line for each thing you send". Also look at the name of every file in every folder: any with "key" anywhere in its name, in capitals or not, is misplaced, and you don't open it. Keep your reply short, and end it with exactly one of these lines: "Ready for Lab 5." or "Not yet:" followed by the first missing or misplaced item and the one step that fixes it.
```

```done
Claude's last line says "Ready for Lab 5." If it names a file with "key" in its name, move that file out of `AI-Labs` by hand, then check again.
```

- Why this way: it uses "end with one clear line" from Ways to ask Claude (see hub-ways.md), so the last line tells you at a glance whether you're set.
- Browser: check by hand for the recipe, the change log and a ship-log line, and move out any file with "key" in its name. Then tap Done.

## Use it again

Your cleanup recipe fits any sheet you clean on a schedule; change your answers to its questions.

| Where else | What you'd change |
|---|---|
| **A grants pipeline** you update monthly | Make the funder column yellow, and reconcile against your finance system. |
| **Attendance by site**, in counts | Keep site names green, and add a limit that sites never merge. |
| **Budget against actuals** | Merge salary lines into one staff line first, keep account codes green, and reconcile against the ledger. |

## What's in your folder now

**Desktop:** this is the folder layout. **Browser:** keep the same named files in Project files or as copies to attach to your next chat. Local download folders are optional and do not connect to Claude.

```
AI-Labs/
  AGENTS.md
  TO-DO.md                         "Before Lab 5" added
  Kits/                            this kit and the practice sheet (new)
  Working/
    volunteer-hours-swapped.csv    (new)
  Org-Brain/
  Recipes/
    second-chair.md
    volunteer-hours-cleanup.md     (new)
  Outputs/
    volunteer-hours-cleaned.csv    (new)
    volunteer-hours-change-log.md  (new)
    ship-log.md
```

Outside every Claude-accessible folder, Project and chat attachment: your own export, the preparation copy, the placeholder key and the sheet with real names restored. Keep these in your permitted private storage, never in a folder Claude can read. On the practice route, today's files start with `grants-`.
