<!-- Lab Guide 1.0.26 · Oct 16, 2026. Mirrored from the participant page as published on Oct 16, 2026 (source d1b375b). Do not edit: rebuild instead. -->

# The seven labs and what each one is for

## The seven labs

Each lab has a kit. Every build runs on your own material or a practice file, and both take the same steps. Before the session, save the kit and its practice files into your Kits folder, whether you'll use your own material or the practice file, so you can ask Claude about them. The one exception is the Lab 4 practice key, which stays outside your AI-Labs folder.

### Lab 1: First safe win

One small piece of real writing, checked and ready to send, plus your AI-Labs folder and an AGENTS.md file that Claude writes by interviewing you.

Monday, September 28 · Friday, October 2

#### Browser — Lab 1

Open the worksheet below. Its browser card names the files to upload or attach. Use Project files if available; otherwise attach the latest files to each new chat. Save and check each complete result before continuing.

#### Desktop — Lab 1

Use the same worksheet’s connected-folder steps. Reuse AI-Labs and confirm actual file access. Without folder tools, use the browser attachment steps.

**Before the session:** if you did Start here (see hub-start.md), your Lab 1 files are already in your AI-Labs folder and there's nothing more to set up. This card is what happens in the room. If you saved the Lab 1 kit file on or before September 28, save it once more on Cowork, because it was updated, and drag it into Kits, choosing Replace. If it saves with "(1)" in the name, rename it first.

**How your room works:** about eight people from four organizations, with a facilitator. Each of you works on your own computer with your own Claude, your colleague included: your own interview, your own AGENTS.md, your own piece of writing, checked by a fresh Claude session and then by you. Bring one small piece of real writing each, or use the practice thread. Afterward, email your AGENTS.md to your colleague and read theirs.

**Lab 1 kit**: What happens in the session, step by step, and the homework for the week after. If you did Start here, there's nothing more to set up: the kit starts with today's steps, and setup sits in its own section at the end for anyone who skipped it. (lab-1.md)

**Need a file again? The Lab 1 kit, the practice email thread, the interview prompt, and the ship log for the browser version**

Save the Lab 1 kit as a file: KIT-Lab1-First-Safe-Win.md (lab-1.md)

**Practice file: program update email thread**: Only for anyone who doesn't bring their own writing. Made-up emails from a fictional nonprofit; in the lab, Claude turns them into a short board update and you check it against the emails.

**Starter AGENTS.md**: The interview prompt Claude uses to write your AGENTS.md in the session, and the six empty headings.

**Starter ship log**: Browser: save a copy named ship-log.md, then add it to Project files or attach it to your chat. Outputs is an optional local download folder. In Cowork, prompt 1 makes it for you.

### Lab 2: Writing and the org brain

Save written notes about your organization's writing style. Then draft one useful piece, or make a table matching a funder's requirements to supporting evidence and any gaps.

Monday, October 5 · Friday, October 9

#### Browser — Lab 2

Open the worksheet below. Its browser card names the files to upload or attach. Use Project files if available; otherwise attach the latest files to each new chat. Save and check each complete result before continuing.

#### Desktop — Lab 2

Use the same worksheet’s connected-folder steps. Reuse AI-Labs and confirm actual file access. Without folder tools, use the browser attachment steps.

**Today’s finish line:** written notes about your organization’s writing style and five approved voice rules, saved and reopened. “Org-Brain” means the folder for reusable organization information. A draft is the next goal when time permits; sending it is separate homework. The writing checks are already included, so extra skill uploads are optional.

Already working here? If the current guide check and your saved-file readback work, continue in this conversation with your existing Project or folder. Do not reinstall the guide or recreate your Project.

### I'm using Claude in my browser

Open your AI-Labs Project and your work chat. Download the text guide, then attach it to the chat. Check that lab-guide-chat.md appears there and ask “Is the guide working?” Claude should confirm the current version and read the Lab 2 instructions.

When you finish, save the approved files to Project files and open them to check the contents. Downloading saves a local copy; it does not update Project files. See the browser saving steps.

### I'm using the Claude desktop app

Download the guide ZIP and keep it zipped. In Customize → Skills, choose + → Create skill → Upload a skill, select the ZIP and enable lab-guide, where offered. Open your work conversation and ask “Check and fix setup.” Choose your existing AI-Labs folder if access is requested. Claude names the files it can actually read, or explains what is missing. Installing the guide does not connect the folder. Ask “Is the guide working?”

**Then, in either path, say:** `I'm ready to begin Lab 2.`

Claude asks one question at a time. You approve the voice, check facts and keep the saved result. Start with voice notes; draft a piece if time permits. Use permitted public material or fictional practice. Remove restricted information before sharing, and keep practice separate from your real voice.

**Help: no Project, missing controls or trouble saving**

No Project is required: attach the text guide to a regular chat and keep the complete files for your next chat. Missing Skills or Cowork controls do not prove a file-access failure. Use the help for your screen; Claude checks actual tools and permissions. The browser saving steps cover Save to Project where offered, download then upload, and checking Project files before a fresh-chat readback. Text-only saving help is also there.

The Lab 2 worksheet (lab-2.md) is a reference if you want it. You do not need to read it first or choose the next prompt.

**Lab 2 kit**: Start with “I’m ready to begin Lab 2.” Claude checks connected files and leads the work one question at a time, handling files and pausing for your approvals. This worksheet is an optional reference. (lab-2.md)

**Practice file: org brain starter pack**: Documents from BrightPath, a fictional nonprofit: its mission, two writing samples, outcomes and a practice RFP. It takes the same steps as your own documents.

**Lab 3 preflight:** in your work chat, ask “Check my Lab 3 access.” Check that Claude can read the guide or current kit and your actual input. Then say “I'm ready to begin Lab 3.” If the installed guide does not recognize that mode, attach the current Lab 3 kit and use its “Begin with the guide” instructions. Keep the draft *and its sources* available in every fresh review. GitHub connection is not required.

### Lab 3: Board-ready reporting and the second chair

One report section taken through draft, critique and revision, and a saved second chair that reads drafts the way your most skeptical board member would.

Monday, October 12 · Friday, October 16

#### Browser — Lab 3

Open the worksheet below. Its browser card names the files to upload or attach. Use Project files if available; otherwise attach the latest files to each new chat. Save and check each complete result before continuing.

#### Desktop — Lab 3

Use the same worksheet’s connected-folder steps. Reuse AI-Labs and confirm actual file access. Without folder tools, use the browser attachment steps.

**Lab 3 kit**: Draft, critique and revise one report section, from your own reporting input or the practice mess pack. (lab-3.md)

**Practice file: the mess pack**: A fictional nonprofit's meeting notes, partial sheet and emails for a board update. Save it into Kits, whichever material you choose.

### Lab 4: Data, clean and extract

A spreadsheet cleaned by Claude, your own recurring one or the practice sheet, with every change in a change log you've checked, the organization names back in, and a cleanup recipe for next month. People's names never go into Claude, and organization names reach it only as placeholders like ORG-01.

Monday, October 19 · Friday, October 23

#### Browser — Lab 4

Open the worksheet below. Its browser card names the files to upload or attach. Use Project files if available; otherwise attach the latest files to each new chat. Save and check each complete result before continuing.

#### Desktop — Lab 4

Use the same worksheet’s connected-folder steps. Reuse AI-Labs and confirm actual file access. Without folder tools, use the browser attachment steps.

**Lab 4 kit**: Step by step: a copy of your sheet with its headers checked, your placeholder key, a clean on 10 rows first, your own count and your cleanup recipe. (lab-4.md)

**Practice file: messy grants sheet**: A fictional funder's grants export with the kind of mess a real export has. Desktop: save it in AI-Labs/Kits. Browser: attach it to your chat or add it to Project files. The learning steps are the same.

**Practice placeholder key (save it outside AI-Labs, never in Kits)**: Matches each placeholder, like ORG-01, to a fictional organization's name in the practice sheet. Keys never go near Claude, so save this one in a folder outside your AI-Labs folder, even though it's practice.

### Lab 5: Numbers to narrative to deck

Checked insights, a checked narrative and a slide outline for an upcoming meeting, yours or the practice set's, plus a slide deck (.pptx) started with Claude and finished at home if needed.

Monday, October 26 · Friday, October 30

#### Browser — Lab 5

Open the worksheet below. Its browser card names the files to upload or attach. Use Project files if available; otherwise attach the latest files to each new chat. Save and check each complete result before continuing.

#### Desktop — Lab 5

Use the same worksheet’s connected-folder steps. Reuse AI-Labs and confirm actual file access. Without folder tools, use the browser attachment steps.

**Lab 5 kit**: Numbers to insights to a checked narrative to a slide outline to a deck, each checked before the next, with your own numbers or the practice set. (lab-5.md)

**Practice file: grants sheet, cleaned**: A fictional funder's 57 cleaned grants from 2024 and 2025, the numbers for the practice set.

**Practice file: context for the committee**: What the practice numbers can't show, and the funder's quarterly committee the deck is for.

### Lab 6: Skills, research and the wider toolbox

Your second chair saved as a skill and run on a real draft, and a one-page summary of a Claude Research report, with its claims checked at the source.

Monday, November 2 · Friday, November 6

#### Browser — Lab 6

Open the worksheet below. Its browser card names the files to upload or attach. Use Project files if available; otherwise attach the latest files to each new chat. Save and check each complete result before continuing.

#### Desktop — Lab 6

Use the same worksheet’s connected-folder steps. Reuse AI-Labs and confirm actual file access. Without folder tools, use the browser attachment steps.

**Lab 6 kit**: Saving your second chair as a skill, running Research and checking it at the source, step by step. The map of other AI tools is at the end. (lab-6.md)

**Practice file: grants sheet, cleaned (from Lab 5)**: The numbers behind the practice narrative you wrote in Lab 5, for running your skill on it. Save it into Kits if it isn't there already, whichever draft you pick.

**Practice file: context for the committee (from Lab 5)**: The context file that goes with those numbers. Save it into Kits if it isn't there already, whichever draft you pick.

### Lab 7: Build session and 90-day roadmap

A written workflow a colleague could run without you, timed before and after and shown to your room, and a plan for the next 90 days.

Monday, November 9 · Friday, November 13

#### Browser — Lab 7

Open the worksheet below. Its browser card names the files to upload or attach. Use Project files if available; otherwise attach the latest files to each new chat. Save and check each complete result before continuing.

#### Desktop — Lab 7

Use the same worksheet’s connected-folder steps. Reuse AI-Labs and confirm actual file access. Without folder tools, use the browser attachment steps.

**Lab 7 kit**: Writing your workflow down, checking it, and your 90-day plan. The workflow can be your own or the one you ran on the Lab 4 and 5 practice files; both take the same steps. (lab-7.md)
